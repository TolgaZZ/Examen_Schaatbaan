<?php
class connection
{
    private $mysqli; // $this->$connection = "hallo";
    
    public function connect($db_hostname, $db_username, $db_password, $db_database)
    {
        if($this->mysqli = mysqli_connect($db_hostname, $db_username, $db_password, $db_database))
		{
            mysqli_select_db($this->mysqli, $db_database);
		}
		else
			echo 'error while opening connection';
    }

    public function returnConnection()
	{
		return $this->mysqli;
	}
}
?>
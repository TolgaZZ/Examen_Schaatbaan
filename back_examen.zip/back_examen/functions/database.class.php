<?php

class database
{
	private $query;
	private $mysqli;

    /* 
        Old school
        $mysqli = mysqli_connect($db_hostname, $db_username, $db_password, 'test');
        $mysqli -> select_db($db_database);
        $query =  "SELECT * FROM `users`";
        $result = mysqli_query($mysqli, $query);
    */

    public function __construct() {
		$this->mysqli = new connection();
		$this->mysqli->connect("localhost","Tolga_Z","Tolga-2001","docent_test_net");
	}

	// public function executeVoid($query) //Voorbeeld: SELECT * FROM `users`
	// {
	// 	$this->query = mysqli_multi_query($this->mysqli->returnConnection(), $query);
	// }

    public function execute($query) //Voorbeeld: SELECT * FROM `users`
	{
		return $this->query = mysqli_query($this->mysqli->returnConnection(), $query);
	}

    public function rowsFound()
	{
		if(mysqli_num_rows($this->query) > 0)
		{
			//debug::message("Selected Row found returning results","INFO");
			return true;
		}
		else
		{
			//debug::message("No rows found","INFO");
			return false;	
		}
	}

	public function getLevel()
	{
		return mysqli_fetch_object($this->query)->level; // level is niet dynamisch maar goed.
	}
}

?>
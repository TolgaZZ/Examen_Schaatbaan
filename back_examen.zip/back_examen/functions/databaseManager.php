<?php

class databaseManager 
{
    private $db;

	public function __construct()
	{
		//debug::message("Database manager instance created","INFO");
		$this->db = new database();
	}

    public function login($username,$password)
	{
		//debug::message("Finding Account : $username with the password : $password","INFO");
		$this->db->execute("SELECT `username`, `password` FROM `users` WHERE `username` = '$username' && `password` = '$password'");
		return $this->db->rowsFound();
	}

	public function getUserLevel()
	{
		if(isset($_SESSION['logged']['username'])){
			$username = $_SESSION['logged']['username'];
			$this->db->execute("SELECT `level` FROM `users` WHERE `username` = '$username'");
			return $this->db->getLevel();
		}
	}

	public function getUserList()
	{
		return $this->db->execute("SELECT `ID`,`username` FROM `users` ORDER BY `username` ASC");
	}

	public function getStatusList()
	{
		return $this->db->execute("SELECT `pk_statusID`,`dsp_name` FROM `status` ORDER BY `dsp_name` ASC");
	}

	public function selectReservation()
	{
		//$this->db->execute("INSERT INTO `invoices` (`Invoice_ID`, `Date`, `Price_exc`, `Price_inc`, `VAT`, `pk_statusID`, `fk_profileID`) VALUES ('22222', '2021-03-01', NULL, NULL, NULL, '3', '1');");
		return $this->db->execute("SELECT * FROM reservations i INNER JOIN users u ON i.fk_profileID = u.ID INNER JOIN status s ON i.pk_statusID = s.pk_statusID");
		// return $this->db->execute("SELECT * FROM `status`;");
	
	}

	public function insertReservation($invoiceid,$invoicedate, $invoice_Status, $invoice_Profile, $abc)
	{
		//$this->db->execute("INSERT INTO `invoices` (`Invoice_ID`, `Date`, `Price_exc`, `Price_inc`, `VAT`, `pk_statusID`, `fk_profileID`) VALUES ('22222', '2021-03-01', NULL, NULL, NULL, '3', '1');");
		$this->db->execute("INSERT INTO `invoices` (`Invoice_ID`, `Date`, `pk_statusID`, `fk_profileID`, `fileURL`) VALUES ('$invoiceid' , '$invoicedate', NULL, '$invoice_Status', '$invoice_Profile', '$abc');");
	}

	public function insertUser($username, $password, $firstname, $lastname , $email , $phone , $address, $zipcode, $city , $level)
	{
		//$this->db->execute("INSERT INTO `invoices` (`Invoice_ID`, `Date`, `Price_exc`, `Price_inc`, `VAT`, `pk_statusID`, `fk_profileID`) VALUES ('22222', '2021-03-01', NULL, NULL, NULL, '3', '1');");
		//$this->db->executeVoid("INSERT INTO `users` (`ID`, `username`, `password`, `level`) VALUES (NULL, '$username', '$password', '$level'); INSERT INTO `profiles` (`fk_userID`, `kvk`, `company`, `firstname`, `lastname`, `email`, `phone`, `address`, `zipcode`, `city`) VALUES (LAST_INSERT_ID(), '$kvk', '$company', '$firstname', '$lastname', '$email', '$phone', '$address', '$zipcode', '$city');");
		$this->db->execute("INSERT INTO `users` (`ID`, `username`, `password`, `level`) VALUES (NULL, '$username', '$password', '$level');");
		// $this->db->execute("DO SLEEP(2);");
		$this->db->execute("INSERT INTO `profiles` (`fk_userID`, `firstname`, `lastname`, `email`, `phone`, `address`, `zipcode`, `city`) VALUES (LAST_INSERT_ID(),'$firstname', '$lastname', '$email', '$phone', '$address', '$zipcode', '$city');");
		// $this->db->execute("DO SLEEP(1);");
	}

	public function updateReservation($invoiceid,$invoicedate, $invoice_Profile, $invoice_Status, $xyz)
	{
		//$this->db->execute("INSERT INTO `invoices` (`Invoice_ID`, `Date`, `pk_statusID`, `fk_profileID`) VALUES ('22222', '2021-03-01', '3', '1');");
		$this->db->execute(""
		. "UPDATE `invoices` SET "
		. "`Invoice_ID` = '$invoiceid', "
		. "`Date` = '$invoicedate', "
		. "`fk_profileID` = '$invoice_Profile', "
		. "`pk_statusID` = '$invoice_Status' WHERE `Invoice_ID` = '$xyz';");
		echo $invoicedate . " Uw gegevens zijn geupdate " ;
	}

}

?>
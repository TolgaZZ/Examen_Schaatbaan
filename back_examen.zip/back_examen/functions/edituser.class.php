<?php
include "../config.php";

//lees alle formulierbestand
$id     =       $_POST['Id'];
$date =       $_POST['Date'];
$status =   $_POST['Status'];

//controleer of alle formuliervelden waren ingevuld
if (is_numeric($id) &&
    strlen($id)           > 0 &&
    strlen($date)   > 0 &&
    strlen($price_exc)    > 0 &&
    strlen($price_inc)   > 0 &&
    strlen($status)       > 0) {
     

//alle data zijn OK, maak de query
$query= "UPDATE invoices
            SET `Invoice_ID` = 
            `Id` = '$id',
            `Date` = '$date',

            member_since = '$status'
             WHERE id = $id";

$query= "UPDATE `invoices` SET 
`Invoice_ID` = '231', 
`Date` = '2021-03-12', 
`pk_statusID` = '1', 
`fk_profileID` = '3' 
WHERE `invoices`.`Invoice_ID` = '232';";


//voer de query uit
$result = mysqli_query($mysqli, $query);

//controleer het resultaat
if($result){
    //alles ok, stuur terug naar de homepage
    header("location:dashboard.php");
    exit;
} else{  
    echo'er ging wat mis met het toevoegen!';
}
}else{
    // er is iets mis met een datum
    echo'een van de ingevulde data was ongeldig!';
}
 }else{
    echo'niet alle velden waren ingevuld!';
 }
?>

?>
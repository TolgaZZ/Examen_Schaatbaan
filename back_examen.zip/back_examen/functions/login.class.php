<?php
class Login 
{
    private $query;

	public function __construct()
	{
		$this->query = new databaseManager();	
	}
	
	public function login($username,$password)
	{
		if($this->query->login($username,$password))
		{
			$_SESSION['logged']['status'] = true;
			$_SESSION['logged']['username'] = $username;
			$_SESSION['logged']['userLevel'] = $this->query->getUserLevel();
			return true;
		}
		else {
			return false;
		}
	}
}
?>


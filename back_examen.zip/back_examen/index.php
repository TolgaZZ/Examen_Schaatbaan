<?php 
include "config.php";

if(isset($_POST['login']) && isset($_POST['username']))
{
	$login = new login();
	if($login->login($_POST['username'],$_POST['password']))
	{
        header('Location: pages/dashboard.php');
        echo "test je username is: " . $_SESSION['logged']['username'] . "<br />";
        echo "blabla " . $_SESSION['logged']['userLevel'] . "<br />";
		// if ($_SESSION['logged']['userLevel'] > 1) {
        //     echo "Ik ben admin mijn level is 999 - " . $_POST['username'];
		// } else {
        //     echo "Ik ben geen admin mijn level is 0 - " . $_POST['username'];            
		// }
	}
}
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">
    <title>Schaatsbaan Login</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/sign-in/">
    <link href="../../dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="styles/signin.css" rel="stylesheet">
  </head>

  <body class="text-center">
    <form class="form-signin" method='post'>
      <h1 class="h3 mb-3 font-weight-normal ">Schaatsbaan Login</h1>
      <label for="username" class="sr-only ">Gebruikersnaam</label>
      <input type="text" id="username" name="username" value="Admin" class="form-control" placeholder="Gebruikersnaam" required autofocus>
      <label for="inputPassword" class="sr-only ">Wachtwoord</label>
      <input type="password" id="password" name="password" value="#1Geheim" class="form-control" placeholder="Wachtwoord" required>
      <div class="checkbox mb-3">
        <label>
          <input type="checkbox" value="remember-me"> Onthoud mij
        </label>
      </div>
      <button class="btn btn-lg btn-primary btn-block" type="submit" value="login" name="login">Inloggen</button>
    </form>
  </body>
</html>



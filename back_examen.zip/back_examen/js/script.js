$(".js-open-modal-invoice").click(function(){
    $(".modal-invoice").addClass("visible");
  });
  
  $(".js-close-modal-invoice").click(function(){
    $(".modal-invoice").removeClass("visible");
  });
  
  $(document).click(function(event) {
    //if you click on anything except the modal itself or the "open modal" link, close the modal
    if (!$(event.target).closest(".modal-user,.js-open-modal-invoice").length) {
      $("body").find(".modal-invoice").removeClass("visible");
    }
  });



  $(".js-open-modal-user").click(function(){
    $(".modal-user").addClass("visible");
  });
  
  $(".js-close-modal-user").click(function(){
    $(".modal-user").removeClass("visible");
  });
  
  $(document).click(function(event) {
    //if you click on anything except the modal itself or the "open modal" link, close the modal
    if (!$(event.target).closest(".modal-user,.js-open-modal-user").length) {
      $("body").find(".modal-user").removeClass("visible");
    }
  });  
<?php

include "../config.php";

$dbManager = new databaseManager();
if (isset($_POST['send'])) {
  $dbManager->insertReservation($_POST['Id'], $_POST['Date'], $_POST['pk_statusID'], $_POST['fk_profileID'], $abc);
}
if (isset($_POST['verzend'])) {
  $dbManager->insertUser($_POST['username'], $_POST['password'], $_POST['firstname'], $_POST['lastname'], $_POST['email'], $_POST['phone'], $_POST['address'],  $_POST['zipcode'], $_POST['city'], $_POST['level']);
}

?>
<html>

<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="styles/dashboard.css">
</head>

<body>
  <nav class="nav navbar-dark"> 
  <a class="nav-link text-decoration:none; " href="reserveren.php">  <button type="button" class="btn btn-primary">Reserveren</button></a>
  <a class="nav-link text-decoration:none; " href="reserveren.php">  <button type="button" class="btn btn-primary">Annuleren</button></a>
  <a class="nav-link text-decoration:none; " href="reserveren.php">  <button type="button" class="btn btn-primary">Mensen toevoegen</button></a>
  <span class="time"><?php echo date("l jS, F Y"); ?></span>

</nav>


  


  <!-- <a href="#" class="app-sidebar-link js-open-modal-user" title="Gebruiker toevoegen">
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <line x1="12" y1="5" x2="12" y2="19"></line>
    <line x1="5" y1="12" x2="19" y2="12"></line>
  </svg>
</a> -->

  <!-- <div class="modal-user">
  <div class="modal__header">
    Gebruiker toevoegen
    <a href="#" class="js-close-modal-user">X</a>
  </div>
  <form method="post" enctype="multipart/form-data">
    <label for="username">Gebruikersnaam:</label><br>
    <input type="text" name="username" value=""><br>
    <label for="password">Wachtwoord:</label><br>
    <input type="text" name="company" value=""><br>
    <label for="text">Voornaam:</label><br>
    <input type="text" name="firstname" value=""><br>
    <label for="text">Achternaam:</label><br>
    <input type="text" name="lastname" value=""><br>

    <label for="text">Telefoon Nummer:</label><br>
    <input type="number" name="phone" value=""><br>
    <label for="text">email:</label><br>
    <input type="email" name="email" value=""><br>
    <label for="text">adres:</label><br>
    <input type="text" name="address" value=""><br>
    <label for="text">postcode:</label><br>
    <input type="te" name="zipcode" value=""><br>
    <label for="text">stad:</label><br>
    <input type="text" name="city" value=""><br>

    <label for="level">Bevoegdheid</label><br>
    <select name="level">
      <option value="1">Gebruiker</option>
      <option value="2">Administrator</option>
    </select><br><br>
    <div class="button-holder">
      <input type="submit" name="verzend" id="submit" value="Verzend">
    </div>
  </form>
</div> -->
  <div class="overzicht">

    <table class='table'>
      <thead class="thead-dark">
        <?php
        echo "<table class='table'>";
        echo "<thead class='thead-dark'>";
        echo "<tr>";

        echo "<th scope='col'>Factuur nummer</th>";
        echo "<th scope='col'>Datum</th>";
        echo "<th scope='col'></th>";
        echo "<th scope='col'></th>";
        echo "</tr>";
        echo "<thead>";
        echo "</table>";

        echo "<div class=\"tblcontent\">";
        echo "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\">";
        foreach ($dbManager->selectReservation() as $data) {
          echo "<tbody>";
          echo "<tr scope='row'>";
          echo "<td>" . $data["Invoice_ID"] . "</td>";
          echo "<td>" . $data["Date"] . "</td>";
          echo "<td>" . $data["dsp_name"] . "</td>";
          echo "<td>" . $data["username"] . "</td>";
          echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
        echo "<div>";
        ?>

  </div>
  <script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
  <script src="../js/script.js"></script>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</html>
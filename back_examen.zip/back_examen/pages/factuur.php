<?php 
include "../config.php";

$dbManager = new databaseManager();

if(isset($_POST['update']))
{
   $dbManager->updateInvoice($_POST['Id'],$_POST['Date'],$_POST['Price_exc'],$_POST['Price_inc'],$_POST['fk_profileID'],$_POST['abchj'], $_POST['currentUser']);
}

if(isset($_GET['Id']))
{
$id = $_GET['Id'];


$mysqli = mysqli_connect("localhost","root","","md509732db549581");


if(!$mysqli){
  
    echo "Fout geen connectie naar database. <br>";
    echo "Errno: ". mysqli_connect_errno() . "<br>";
    echo "Error: ". mysqli_connect_error() . "<br>";
    exit;
}


if (is_numeric($id)){
    $result = mysqli_query($mysqli, "SELECT * FROM invoices i INNER JOIN users u ON i.fk_profileID = u.ID INNER JOIN status s ON i.pk_statusID = s.pk_statusID WHERE i.Invoice_ID = '$id'");
    
    if (mysqli_num_rows($result) == 1){
     $row = mysqli_fetch_array($result);
    } else{
         echo "geen lid gevonden.";
         exit;
    }
 } else {
     echo "Onjuist ID.";
     exit;
 }
 
}
?>
<html>
<head>
<link rel="stylesheet" href="../styles/dashboardstyle.css">
</head>
<body>
  <div class="container">
    <div class="invoice-edit">
          <form method="post">
              <input type="hidden" name="currentUser" value="<?php echo $id?>"><br>
              <label for="Id">Factuur nummer:</label><br>
                <input type="text" name="Id" value="<?php echo $row['Invoice_ID']?>"><br>
              <label for="Date">Factuur datum</label><br>
                <input type="date" name="Date" value="<?php echo date("Y-m-d", strtotime( $row['Date'])) ?>"><br>
              <label for="Price_exc">Prijs inc BTW</label><br>
                <input type="text" name="Price_exc" value="<?php echo $row['Price_exc']?>"><br>
              <label for="Price_inc">Prijs exc BTW</label><br>
                <input type="text" name="Price_inc" value="<?php echo $row['Price_inc']?>"><br><br>

              <label>Naam Klant:</label><br>
              <select id="fk_profileID" name="fk_profileID">
              <?php echo "<option value=\"".$row["fk_profileID"]."\">".$row['username']."</option>";
              

                  foreach ($dbManager->getUserList() as $user )
                  {
                    echo "<option value=\"".$user["ID"]."\">".$user["username"]."</option>";
                  }
              ?>
              </select><br/>
  
              <label for="Status">Status</label><br>
                <select id="Status" name="abchj">
                <?php echo "<option value=\"".$row["pk_statusID"]."\">".$row['dsp_name']."</option>";
              

              foreach ($dbManager->getStatusList() as $status )
              {
                echo "<option value=\"".$status["pk_statusID"]."\">".$status["dsp_name"]."</option>";
              }
          ?>
                </select><br><br>
                  <div class="button-holder">
                    <input type="submit" name="update" id="submit" value="Verzend">
                  </div>
          </form>
        </div>
      </div>

<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-alpha1/jquery.min.js'></script>
<script  src="../js/dashboard.js"></script>
</body>
</html>
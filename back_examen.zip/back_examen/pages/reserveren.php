<?php
include "../config.php";

$dbManager = new databaseManager();
if (isset($_POST['send'])) {
  $dbManager->insertReservation($_POST['Id'], $_POST['Date'], $_POST['pk_statusID'], $_POST['fk_profileID'], $_POST['timeSpace']);
}




?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

</head>
<body>
<div class="modal-invoice">
  <form method="post">



    <label for="timeSpace">Tijdblock</label>
      <select id="timeSpace" class="form-control">
        <option selected>Tijd Blok</option>
        <option>10:00 / 11:30</option>
        <option>11:30 / 13:00</option>
        <option>13:00 / 14:30</option>
        <option>14:30 / 16:30</option>
        <option>16:30 / 17:30</option>
        <option>17:30 / 19:00</option>

    </select>

</div> 



<form>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
  </div>
  <div class="form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>



<button type="button" class="btn btn-dark"><a href="dashboard.php">Terug naar dashboard</a></button>


</body>
</html>
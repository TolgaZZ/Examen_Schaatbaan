<?php 

include "../config.php";

$dbManager = new databaseManager();

      echo "<div class=\"theader\">";
      echo "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\">";
      echo "<thead>";
      echo "<tr>";

      echo "<th>Factuur nummer</th>";
      echo "<th>Datum</th>";
      echo "<th>Prijs exc btw</th>";
      echo "<th>Prijs inc btw</th>";
      echo "<th>Status</th>";
      echo "<th>Klantnaam</th>";
      echo "<th></th>";
      echo "<th></th>";
      echo "</tr>";
      echo "<thead>";
      echo "</table>";
      echo "</div>";

      echo "<div class=\"tblcontent\">";
      echo "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\">";
      foreach ($dbManager->selectReservation() as $data )
      {
        echo "<tbody>";
        echo "<tr>";
        echo "<td>" . $data ["Invoice_ID"] . "</td>";
        echo "<td>" . $data ["Date"] . "</td>";
        echo "<td>" . $data ["Price_exc"] . "</td>";
        echo "<td>" . $data ["Price_exc"] . "</td>";
        echo "<td>" . $data ["dsp_name"] . "</td>";
        echo "<td>" . $data["username"]."</td>";
        echo "<td class=\"bewerk\"><a href=\"http://localhost/erma" . $data ["fileURL"] . " \">Download</a></td>";

        echo "<td class=\"bewerk\"><a href=\"http://localhost/erma/pages/factuur.php?Id=" . $data ["Invoice_ID"] . " \">bewerk</a></td>";
        // echo "<td><a href='lid_verwijder.php?id=".$data ['Invoice_ID']."'>verwijder</a></td>";
        echo "</tr>";
      }
        echo "</tbody>";
        echo "</table>";
        echo "<div>";
      ?>


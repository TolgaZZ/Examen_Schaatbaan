<!doctype html>

<?php
include "config.php";
$dbManager = new databaseManager();
$result_activity = '';

if (isset($_POST['login'])) {
  $login = new login();
  if ($login->login($_POST['inputUsername'], $_POST['inputPassword'])) {
  }
}

if (isset($_SESSION['logged']) && $_SESSION['logged']['usertype'] == 1 && isset($_GET['guid'])) {
  $my_profile = $dbManager->getUser('', $_GET['guid']);
  if (mysqli_num_rows($my_profile) == 1) {
    $user = mysqli_fetch_array($my_profile);
 }
} else if (isset($_SESSION['logged'])) {
  $my_profile = $dbManager->getUser($_SESSION['logged']['username'], -1);
  if (mysqli_num_rows($my_profile) == 1) {
    $user = mysqli_fetch_array($my_profile);
 }
}

if (isset($_POST['signup'])) {
  if ($_POST['iUsername'] !== '' && $_POST['inputPassword_i'] == $_POST['inputPassword_ii']) {
    $dbManager->insertUser($_POST['iUsername'], $_POST['inputPassword_i'], $_POST['iFirstname'], $_POST['iLastname'], $_POST['iEmail'], $_POST['iPhone'], $_POST['iAddress'], $_POST['iZipcode'], $_POST['iCity']);
    $result_activity = "Uw account is aangemaakt.";
  }
}

if (isset($_POST['update'])) {
  if ($_POST['iUsername'] !== '' && $_POST['inputPassword_i'] == $_POST['inputPassword_ii']) {
    $dbManager->updateUser($_POST['userID'], $_POST['iUsername'], $_POST['inputPassword_i'], $_POST['iFirstname'], $_POST['iLastname'], $_POST['iEmail'], $_POST['iPhone'], $_POST['iAddress'], $_POST['iZipcode'], $_POST['iCity'], $_POST['exampleFormControlSelect1'],$_POST['admin']);
    $result_activity = "Uw account is bijgewerkt.";
  }
}
?>

<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <title>De Klapschaats</title>

  <!-- Bootstrap core CSS -->
  <link href="/assets/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">

  <!-- Favicons -->
  <!-- Fase 3 SEO optimalisatie -->

  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
  </style>

  <!-- Custom styles for this template -->
  <link href="/assets/thema/jumbotron.css" rel="stylesheet">
</head>

<body>

  <?php include('snippets/navigation.php'); ?>

  <main role="main">

    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron">
      <div class="container">
        <h1 class="display-3">De Klapschaats!</h1>

        <?php
        if (isset($_SESSION['logged'])) {
          echo "<p>Heeft u al een account log a.u.b. in of maak een account aan.</p>";
        } else {
        ?>
          <br />
          <p>Voor account bijwerken log a.u.b. in of kies nieuw account aanmaken.</p>
          Dummy data: Hans002 | 123456 <br><br>
          <form action="<?php print $_SERVER['PHP_SELF'] ?>" method='post'>
            <div class="">
              <label for="inputUsername">Gebruikersnaam</label>
              <input class="" id="inputUsername" name="inputUsername" value="">
            </div>
            <div class="">
              <label for="inputPassword">Wachtwoord</label>
              <input type="password" class="" id="inputPassword" name="inputPassword" value="">
            </div>
            <button type="submit" name="login" value="true" class="btn btn-primary">login</button>
          </form>
        <?php
        }
        ?>

      </div>
    </div>

    <?php
    if (isset($_SESSION['logged'])) {
    ?>

<div class="container">
      <div class="row">
        <div class="col-md-12 mb-3">

        <strong>Werk account bij: </strong>
        <?php if($result_activity !== '') { echo '<p>' . $result_activity . '</p>';} ?>

        <form action="<?php print $_SERVER['PHP_SELF'] ?>" method='post'>

        <input type="hidden" class="form-control" id="userID" name="userID" value="<?php echo $user['ID']; ?>">
                                                                                                      
            <div class="form-group">
              <label for="iUsername">Gebruikersnaam</label>
              <input class="form-control" id="iUsername" name="iUsername" value="<?php echo $user['gebruikersnaam']; ?>">
            </div>
            <div class="form-group">
              <label for="inputPassword">Wachtwoord</label>
              <input type="password" class="form-control" id="inputPassword_i" name="inputPassword_i" value="">
            </div>
            <div class="form-group">
              <label for="inputPassword">Herhaal wachtwoord</label>
              <input type="password" class="form-control" id="inputPassword_ii" name="inputPassword_ii" value="">
            </div>
            <div class="form-group">
              <label for="firstName">Voornaam:</label>
              <input type="text" class="form-control" id="iFirstname" name="iFirstname" placeholder="Voornaam" value="<?php echo $user['voornaam']; ?>">
            </div>
            <div class="form-group">
              <label for="lastName">Achternaam:</label>
              <input type="text" class="form-control" id="iLastname" name="iLastname" placeholder="Achternaam" value="<?php echo $user['achternaam']; ?>">
            </div>  
            <div class="form-group">
              <label for="exampleInputEmail1">Email address</label>
              <input type="email" class="form-control" id="iEmail" name="iEmail" aria-describedby="emailHelp" placeholder="Email adress" value="<?php echo $user['email']; ?>">
            </div>
            <div class="form-group">
              <label for="phone">Telefoon Nummer:</label>
              <input type="number" class="form-control" id="iPhone" name="iPhone" placeholder="06123456789" value="<?php echo $user['telefoon']; ?>">
            </div>
          
            <div class="form-group">
              <label for="address">Adress</label>
              <input type="text" class="form-control" id="iAddress" name="iAddress" placeholder="Adress"value="<?php echo $user['adres']; ?>">
            </div>
            <div class="form-group">
              <label for="text">postcode:</label>
              <input type="text" class="form-control" name="iZipcode" name="iZipcode" placeholder="Postcode" value="<?php echo $user['postcode']; ?>">
            </div>
            <div class="form-group">
              <label for="text">stad:</label>
              <input type="text" class="form-control" name="iCity" name="iCity" placeholder="Stad" value="<?php echo $user['plaats']; ?>">
            </div>

            <?php
            if (isset($_SESSION['logged']) && $_SESSION['logged']['usertype'] == 1) {
          ?>
            <div class="form-group">
              <label for="exampleFormControlSelect1">Lid</label>
              <select class="form-control" id="exampleFormControlSelect1" name="exampleFormControlSelect1">
                  <?php 
                    echo '<option value="' . $user['lid'] . '">';
                    if($user['lid'] == 1){ echo "Lid"; } else { echo "Geen lid"; }
                    echo '</option>';
                  ?>
                  <option value="1">Lid</option>
                  <option value="2">Geen lid</option>
              </select>
            </div>

            <div class="form-group">
              <label for="admin">Rechten</label>
              <select class="form-control" id="admin" name="admin">
              <?php 
                echo '<option value="' . $user['type'] . '">';
                if($user['type'] == 1) { echo "Admin"; } else { echo "Default"; }
                echo '</option>';
              ?>
                  <option value="1">Admin</option>
                  <option value="2">User</option>
              </select>
            </div>

            <?php
          }
          ?>
            <button type="submit" name="update" value="true" class="btn btn-primary">Update</button>
            <button type="button" class="btn btn-dark mx-auto"><a href="/">Terug naar home</a></button>
          </form>        
          

        </div>
      </div>
    </div>

    <?php
    } else {
    ?>

    <div class="container">
      <div class="row">
        <div class="col-md-12 mb-3">

        <strong>Registeren: </strong>
        <?php if($result_activity !== '') { echo '<p>' . $result_activity . '</p>';} ?>

        <form action="<?php print $_SERVER['PHP_SELF'] ?>" method='post'>
            <div class="form-group">
              <label for="iUsername">Gebruikersnaam</label>
              <input class="form-control" id="iUsername" name="iUsername" value="">
            </div>
            <div class="form-group">
              <label for="inputPassword">Wachtwoord</label>
              <input type="password" class="form-control" id="inputPassword_i" name="inputPassword_i" value="">
            </div>
            <div class="form-group">
              <label for="inputPassword">Herhaal wachtwoord</label>
              <input type="password" class="form-control" id="inputPassword_ii" name="inputPassword_ii" value="">
            </div>
            <div class="form-group">
              <label for="firstName">Voornaam:</label>
              <input type="text" class="form-control" id="iFirstname" name="iFirstname" placeholder="Voornaam">
            </div>
            <div class="form-group">
              <label for="lastName">Achternaam:</label>
              <input type="text" class="form-control" id="iLastname" name="iLastname" placeholder="Achternaam">
            </div>  
            <div class="form-group">
              <label for="exampleInputEmail1">Email address</label>
              <input type="email" class="form-control" id="iEmail" name="iEmail" aria-describedby="emailHelp" placeholder="Email adress">
            </div>
            <div class="form-group">
              <label for="phone">Telefoon Nummer:</label>
              <input type="number" class="form-control" id="iPhone" name="iPhone" placeholder="06123456789">
            </div>
          
            <div class="form-group">
              <label for="address">Adress</label>
              <input type="text" class="form-control" id="iAddress" name="iAddress" placeholder="Adress">
            </div>
            <div class="form-group">
              <label for="text">postcode:</label>
              <input type="text" class="form-control" name="iZipcode" name="iZipcode" placeholder="Postcode">
            </div>
            <div class="form-group">
              <label for="text">stad:</label>
              <input type="text" class="form-control" name="iCity" name="iCity" placeholder="Stad">
            </div>

            <?php
            if (isset($_SESSION['logged']) && $_SESSION['logged']['usertype'] == 1) {
          ?>
            <div class="form-group">
              <label for="exampleFormControlSelect1">Example select</label>
              <select class="form-control" id="exampleFormControlSelect1" name="exampleFormControlSelect1">
                  <option value="1">Lid</option>
                  <option value="2">Geen lid</option>
              </select>
            </div>
            <?php
          }
          ?>
            <button type="submit" name="signup" value="true" class="btn btn-primary">Registeren</button>
            <button type="button" class="btn btn-dark mx-auto"><a href="/">Terug naar home</a></button>
          </form>        
          

        </div>
      </div>
    </div>

    <?php
    }
    ?>

  </main>

  <?php include('snippets/footer.php'); ?>

</body>

</html>
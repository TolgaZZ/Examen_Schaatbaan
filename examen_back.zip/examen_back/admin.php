<!doctype html>

<?php
include "config.php"; //dankzij dit worden php libraries ingeladen oftewel net als bij .net dient dit als namespace.
$dbManager = new databaseManager();

if (isset($_POST['login'])) {
  $login = new login();
  if ($login->login($_POST['inputUsername'], $_POST['inputPassword'])) {
    // echo "tes <br>";
    // echo "username: " . $_SESSION['logged']['username'] . "<br>";
    // echo "userType: " . $_SESSION['logged']['usertype'] . "<br>";
  }
}

/* Voordat je onderstaande functies kan aanroepen moet je ingelogd zijn als admin! usertype == 1 */
if (isset($_SESSION['logged']) && $_SESSION['logged']['usertype'] == 1) {
  if (isset($_POST['sbm_program'])) {
    if ($_POST['inputBlockID'] == -1) {
      // roep functie insert_new aan
      if ($_POST['inputBlok'] !== '') {
        $dbManager->insertProgram($_POST['inputBlok'], $_POST['iDate'], $_POST['iDateFrom'], $_POST['iDateTo'], $_POST['iAvailablePlaces']);
      }
    } else {
      // roep functie update aan
      if ($_POST['inputBlok'] !== '') {
        $dbManager->updateProgram($_POST['inputBlockID'], $_POST['inputBlok'], $_POST['iDate'], $_POST['iDateFrom'], $_POST['iDateTo'], $_POST['iAvailablePlaces']);
      }
    }
  }
  // blocks sorteren met guid 
  if (isset($_GET['guid'])) {
    $block_result = $dbManager->getBlock($_GET['guid']);
    if (mysqli_num_rows($block_result) == 1) {
      $block_item = mysqli_fetch_array($block_result);
    } else {
      echo "Geselecteerde 'blok' bestaat niet";
    }
  }

  if (isset($_GET['guid']) && isset($_GET['del'])) {
    if ($_GET['del'] == true) {
      $dbManager->deleteProgram($_GET['guid']);
    }
  }
}

?>

<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <title>Admin dashboard</title>

  <!-- Bootstrap core CSS -->
  <link href="/assets/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">

  <!-- Favicons -->
  <!-- Fase 3 SEO optimalisatie -->

  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
  </style>

  <!-- Custom styles for this template -->
  <link href="/assets/thema/jumbotron.css" rel="stylesheet">
</head>

<body>

  <?php include('snippets/navigation.php'); ?>

  <main role="main">

    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron">
      <div class="container">
        <h1 class="display-3">Admin dashboard</h1>
        Dummy data: Admin | #1Geheim <br><br>


        <?php
        // UserType moet 1 zijn om admin rechten te hebben! voor toevoegen van een programma item
        if (isset($_SESSION['logged']) && $_SESSION['logged']['usertype'] == 1) {
          echo "<p>Welkom admin.</p>";
        } else if (isset($_SESSION['logged']) && $_SESSION['logged']['usertype'] != 1) {
          echo "<p>Je hebt de verkeerde rechten.</p>";
        } else {
        ?>
          <br />
          <p>U bent nog niet ingelogd, log in om aan te melden.</p>
          <form action="<?php print $_SERVER['PHP_SELF'] ?>" method='post'>
            <div class="form-group">
              <label for="inputUsername">Gebruikersnaam</label>
              <input class="form-control" id="inputUsername" name="inputUsername" value="">
            </div>
            <div class="form-group">
              <label for="inputPassword">Wachtwoord</label>
              <input type="password" class="form-control" id="inputPassword" name="inputPassword" value="">
            </div>
            <button type="submit" name="login" value="true" class="btn btn-primary">login</button>
          </form>
        <?php
        }
        ?>

      </div>
    </div>

    <?php
    if (isset($_SESSION['logged']) && $_SESSION['logged']['usertype'] == 1) {
    ?>

      <div class="container">

        <div class="row">
          <div class="col-md-12 mb-3">
            <button type="button" class="btn btn-outline-primary" onclick="document.getElementById('addnewblock').style.display = 'block';">Nieuw</button>
            <a href="<?php print $_SERVER['PHP_SELF'] ?>" class="btn btn-outline-secondary">Reset (F5)</a>
          </div>
        </div>

        <div class="row" id="addnewblock" style="display:none;">
          <div class="col-md-12 mb-3">
            <?php
            if (isset($_GET['guid'])) {
            ?>
              <h2>Update blok:</h2>
            <?php
            } else {
            ?>
              <h2>Maak nieuw blok aan:</h2>
            <?php
            }
            ?>
          </div>

          <div class="col-md-12 mb-5">
            <form action="<?php print $_SERVER['PHP_SELF'] ?>" method='post'>
              <input type="hidden" class="form-control" id="inputBlockID" name="inputBlockID" value="<?php if (isset($_GET['guid'])) echo $block_item['BlokID'];
                                                                                                      else echo -1; ?>">

              <div class="form-group">
                <label for="inputBlok">Dag deel</label>
                <input class="form-control" id="inputBlok" name="inputBlok" value="<?php if (isset($_GET['guid'])) echo $block_item['blok'] ?>">
              </div>
              <div class="form-group">
                <label for="iDate">Datum</label>
                <input class="form-control" id="iDate" name="iDate" value="<?php if (isset($_GET['guid'])) echo date("d-m-Y", strtotime($block_item['datum_van'])); ?>">
              </div>
              <div class="form-group">
                <label for="iDateFrom">Van</label>
                <input class="form-control" id="iDateFrom" name="iDateFrom" value="<?php if (isset($_GET['guid'])) echo date("H:i", strtotime($block_item['datum_van'])); ?>">
              </div>
              <div class="form-group">
                <label for="iDateTo">Tot</label>
                <input class="form-control" id="iDateTo" name="iDateTo" value="<?php if (isset($_GET['guid'])) echo date("H:i", strtotime($block_item['datum_tot'])); ?>">
              </div>
              <div class="form-group">
                <label for="iAvailablePlaces">Aantal beschikbaar plekken</label>
                <input class="form-control" id="iAvailablePlaces" name="iAvailablePlaces" value="<?php if (isset($_GET['guid'])) echo $block_item['aantal_plekken'] ?>">
              </div>
              <button type="submit" name="sbm_program" value="true" class="btn btn-primary">Submit</button>
              <button type="button" class="btn btn-outline-secondary" onclick="document.getElementById('addnewblock').style.display = 'none';">Close</button>
            </form>

          </div>
        </div>
      </div>

    <?php
    }
    ?>

    <div class="container">
      <div class="row">
        <div class="col-md-12 mb-3">
          Schaatsbaan programma:
        </div>
        <div class="col-md-12 mb-3">
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">Blok</th>
                <th scope="col">Datum</th>
                <th scope="col">Van</th>
                <th scope="col">Tot</th>
                <th scope="col">Aantal plekken</th>
                <th scope="col">Verwijder</th>
              </tr>
            </thead>
            <tbody>
              <?php
              foreach ($dbManager->getProgramList() as $row) {
                echo "" .
                  "<tr>" .
                  "<th scope=\"row\">" . $row["blok"] . "</th>" .
                  "<td><a href='" . $_SERVER['PHP_SELF'] . "?guid=" . $row["BlokID"] . "'>" . date("d-M-Y", strtotime($row["datum_van"])) . "</a></td>" .
                  "<td>" . date("H:i", strtotime($row["datum_van"])) . "</td>" .
                  "<td>" . date("H:i", strtotime($row["datum_tot"])) . "</td>";

                if ($row["aantal_plekken"] > 0) {
                  echo "<td>" . $row["aantal_plekken"] . "</td>";
                } else {
                  echo "<td><span style=\"color:red;font-weight:bold;\">vol</span></td>";
                }
                echo "<td><a href='" . $_SERVER['PHP_SELF'] . "?guid=" . $row["BlokID"] . "&amp;del=true'>verwijder</a></td>";
                echo "</tr>";
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>


  </main>


  <script>
    if (window.location.search.indexOf('guid') !== -1 && window.location.search.indexOf('del=true') === -1) {
      document.getElementById('addnewblock').style.display = 'block';
    }
  </script>

  <?php include('snippets/footer.php'); ?>

</body>

</html>
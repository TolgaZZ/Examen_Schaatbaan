-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2021 at 05:44 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `back_examen`
--

-- --------------------------------------------------------

--
-- Table structure for table `administratie`
--

CREATE TABLE `administratie` (
  `fk_gebruikerID` int(11) DEFAULT NULL,
  `fk_blokID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `gebruikers`
--

CREATE TABLE `gebruikers` (
  `ID` int(11) NOT NULL,
  `voornaam` text NOT NULL,
  `achternaam` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefoon` varchar(20) NOT NULL,
  `adres` varchar(95) NOT NULL,
  `postcode` varchar(56) NOT NULL,
  `plaats` varchar(255) NOT NULL,
  `gebruikersnaam` varchar(255) NOT NULL,
  `wachtwoord` varchar(255) NOT NULL,
  `type` int(3) DEFAULT NULL,
  `lid` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `gebruikers`
--

INSERT INTO `gebruikers` (`ID`, `voornaam`, `achternaam`, `email`, `telefoon`, `adres`, `postcode`, `plaats`, `gebruikersnaam`, `wachtwoord`, `type`, `lid`) VALUES
(1, 'Tolga', 'Zorlu', 't.zorlu@test.nl', '06123', 'Leiden', '1111', '1111', 'Tolga001', '123456', 1, NULL),
(2, 'Hans', 'Jan', 'braban@jan.com', '06555544886', 'Valkenborstje', '1527cn', 'hazestad', 'Hans002', '123456', 2, NULL),
(3, 'Kees', 'Roos', 'Kees@jan.com', '06555544886', 'Valkenborstje', '1527cn', 'hazestad', 'Kees003', '123456', 2, NULL),
(4, 'Piet', 'Puck', 'P.puck@oulook.com', '06555544886', 'Valkenborstje', '1527cn', 'hazestad', 'Admin', '#1Geheim', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `programma`
--

CREATE TABLE `programma` (
  `BlokID` int(11) NOT NULL,
  `blok` int(5) DEFAULT NULL,
  `datum_van` datetime DEFAULT NULL,
  `datum_tot` datetime DEFAULT NULL,
  `aantal_plekken` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `programma`
--

INSERT INTO `programma` (`BlokID`, `blok`, `datum_van`, `datum_tot`, `aantal_plekken`) VALUES
(9, 1, '2022-02-05 10:00:00', '2022-02-05 11:30:00', 100),
(11, 3, '2022-02-05 13:00:00', '2022-02-05 14:30:00', 98),
(18, 4, '2022-02-06 14:30:00', '2022-02-06 16:00:00', 49),
(29, 3, '2022-05-02 03:00:00', '2022-05-02 04:30:00', 96),
(30, 4, '2022-05-02 03:00:00', '2022-05-02 04:30:00', 0),
(31, 5, '2022-05-02 03:00:00', '2022-05-02 04:30:00', 49),
(32, 6, '2022-05-02 03:00:00', '2022-05-02 04:30:00', 496),
(33, 7, '2022-05-02 03:00:00', '2022-05-02 04:30:00', 97),
(34, 1, '2022-05-04 03:00:00', '2022-05-04 04:30:00', 97),
(35, 2, '2022-05-04 03:00:00', '2022-05-04 04:30:00', 100),
(36, 3, '2022-05-04 03:00:00', '2022-05-04 04:30:00', -1),
(37, 4, '2022-05-04 03:00:00', '2022-05-04 04:30:00', 100),
(38, 5, '2022-05-04 03:00:00', '2022-05-04 04:30:00', 48),
(39, 6, '2022-05-04 03:00:00', '2022-05-04 04:30:00', 499),
(40, 7, '2022-05-04 03:00:00', '2022-05-04 04:30:00', 100);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administratie`
--
ALTER TABLE `administratie`
  ADD UNIQUE KEY `fk_gebruikerID_2` (`fk_gebruikerID`),
  ADD KEY `fk_gebruikerID` (`fk_gebruikerID`),
  ADD KEY `fk_blokID` (`fk_blokID`);

--
-- Indexes for table `gebruikers`
--
ALTER TABLE `gebruikers`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `programma`
--
ALTER TABLE `programma`
  ADD PRIMARY KEY (`BlokID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `programma`
--
ALTER TABLE `programma`
  MODIFY `BlokID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `administratie`
--
ALTER TABLE `administratie`
  ADD CONSTRAINT `administratie_ibfk_1` FOREIGN KEY (`fk_gebruikerID`) REFERENCES `gebruikers` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `administratie_ibfk_2` FOREIGN KEY (`fk_blokID`) REFERENCES `programma` (`BlokID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php

class database
{
	private $query;
	private $mysqli;

    /* 
        Voorbeeld hoe ik op school heb geleerd.
        $mysqli = mysqli_connect($db_hostname, $db_username, $db_password, $db_database);
        $mysqli -> select_db($db_database);
        $query =  "SELECT * FROM `users`";
        $result = mysqli_query($mysqli, $query);
    */

    public function __construct() {
		$this->mysqli = new connection();
		$this->mysqli->connect("localhost","Tolga_Z","Tolga-2001","docent_test_net");
		// $this->mysqli->connect("localhost","root","","docent_test_net");
	}

    public function execute($query)
	{
		return $this->query = mysqli_query($this->mysqli->returnConnection(), $query);
	}

    public function rowsFound()
	{
		if(mysqli_num_rows($this->query) > 0)
		{
			//debug::message("Selected Row found returning results","INFO");
			return true;
		}
		else
		{
			//debug::message("No rows found","INFO");
			return false;
		}
	}
}
?>
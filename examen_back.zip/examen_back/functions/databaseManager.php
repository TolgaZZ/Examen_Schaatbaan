<?php

class databaseManager 
{
    private $db;

	public function __construct()
	{
		//debug::message("Database manager instance created","INFO");
		$this->db = new database();
	}

	public function getProgramList() {
		return $this->db->execute("SELECT * FROM `programma` ORDER BY `datum_van`, `blok` ASC;");
	}

    public function login($username,$password)
	{
		//debug::message("Finding Account : $username with the password : $password","INFO");
		$this->db->execute("SELECT `gebruikersnaam`, `wachtwoord` FROM `gebruikers` WHERE `gebruikersnaam` = '$username' && `wachtwoord` = '$password';");
		return $this->db->rowsFound();
	}

	public function getUserType($username,$password)
	{
		return $this->db->execute("SELECT `type` FROM `gebruikers` WHERE `gebruikersnaam` = '$username' && `wachtwoord` = '$password';");
	}

	public function getBlock($blockid) {
		return $this->db->execute("SELECT * FROM `programma` WHERE `BlokID` = '$blockid';");
	}

	public function insertUser($iUsername, $iPassword, $iFirstname, $iLastname, $iEmail, $iPhone, $iAddress, $iZipcode, $iCity){
		$this->db->execute("INSERT INTO `gebruikers` (`ID`, `voornaam`, `achternaam`, `email`, `telefoon`, `adres`, `postcode`, `plaats` , `gebruikersnaam`, `wachtwoord`, `type`, `lid`) VALUES (NULL, '$iFirstname', '$iLastname', '$iEmail', '$iPhone', '$iAddress', '$iZipcode', '$iCity', '$iUsername', '$iPassword', 2, 1);");
	}

	public function updateUser($userID, $iUsername, $iPassword, $iFirstname, $iLastname, $iEmail, $iPhone, $iAddress, $iZipcode, $iCity, $iType, $iAdmin){
		$this->db->execute("UPDATE `gebruikers` SET `voornaam` = '$iFirstname', `achternaam` = '$iLastname', `email` = '$iEmail', `telefoon` = '$iPhone', `adres` = '$iAddress', `plaats` = '$iCity', `gebruikersnaam` = '$iUsername', `wachtwoord` = '$iPassword', `type` = '$iType', `lid` = '$iAdmin' WHERE `gebruikers`.`ID` = '$userID';");
	}

	public function getUser($username, $id) {
		if($username != NULL) {
			$userID = mysqli_fetch_object($this->db->execute("SELECT `ID` FROM `gebruikers` WHERE `gebruikersnaam` = '$username';")) -> ID;
		} else {
			$userID = $id;
		}
		return $this->db->execute("SELECT * FROM `gebruikers` WHERE `ID` = '$userID';");
	}

	public function getUserList() {
		return $this->db->execute("SELECT * FROM `gebruikers` ORDER BY `gebruikersnaam` ASC;");
	}

	public function insertProgram($inputBlok, $iDate, $iDateFrom, $iDateTo, $iAvailablePlaces){
		//INSERT INTO `programma` (`BlokID`, `blok`, `datum_van`, `datum_tot`, `aantal_plekken`) VALUES (NULL, '40', '2024-05-14 03:00:00', '2024-05-14 04:30:00', '400');
		$dateFrom = date("Y-m-d H:i:s", strtotime($iDate ." ". $iDateFrom));
		$dateTo = date("Y-m-d H:i:s", strtotime($iDate ." ". $iDateTo));
		$this->db->execute("INSERT INTO `programma` (`BlokID`, `blok`, `datum_van`, `datum_tot`, `aantal_plekken`) VALUES (NULL, '$inputBlok', '$dateFrom', '$dateTo', '$iAvailablePlaces');");
	}

	public function updateProgram($inputBlockID, $inputBlok, $iDate, $iDateFrom, $iDateTo, $iAvailablePlaces) {

		//UPDATE `programma` SET `BlokID` = '22', `blok` = '22', `datum_van` = '2022-02-08 17:30:00', `datum_tot` = '2022-02-08 19:00:00', `aantal_plekken` = '10' WHERE `programma`.`BlokID` = 14;
		$dateFrom = date("Y-m-d H:i:s", strtotime($iDate ." ". $iDateFrom));
		$dateTo = date("Y-m-d H:i:s", strtotime($iDate ." ". $iDateTo));
		// echo $dateFrom . "<br>" . $dateTo . "<br>";
		$this->db->execute("UPDATE `programma` SET `BlokID` = '$inputBlockID', `blok` = '$inputBlok', `datum_van` = '$dateFrom', `datum_tot` = '$dateTo', `aantal_plekken` = '$iAvailablePlaces' WHERE `programma`.`BlokID` = $inputBlockID;");
	}

	public function deleteProgram($inputBlockID) {
		// DELETE FROM `programma` WHERE `programma`.`BlokID` = 25;
		$this->db->execute("DELETE FROM `programma` WHERE `programma`.`BlokID` = '$inputBlockID';");
	}

	public function claimSpot($BlockID, $Blok, $DateFrom, $DateTo, $AvailablePlaces, $username) {
		$setAvailablePlaces = 0;
		if($AvailablePlaces >= 1) {
		// INSERT INTO `administratie` (`fk_gebruikerID`, `fk_blokID`) VALUES ('3', '31');
		$userID = mysqli_fetch_object($this->db->execute("SELECT `ID` FROM `gebruikers` WHERE `gebruikersnaam` = '$username';")) -> ID;
		$this->db->execute("INSERT INTO `administratie` (`fk_gebruikerID`, `fk_blokID`) VALUES ('$userID', '$BlockID');");

		// update beschikbaar plekken met min 1 voor bijhouden van plek.
		
		$setAvailablePlaces = $AvailablePlaces - 1;
		$this->db->execute("UPDATE `programma` SET `BlokID` = '$BlockID', `blok` = '$Blok', `datum_van` = '$DateFrom', `datum_tot` = '$DateTo', `aantal_plekken` = '$setAvailablePlaces' WHERE `programma`.`BlokID` = $BlockID;");
		}

		/* Todo: melding geven schaatsbaan is vol */
	}

	public function getReservation($username) {
		// get my reservation
		$userID = mysqli_fetch_object($this->db->execute("SELECT `ID` FROM `gebruikers` WHERE `gebruikersnaam` = '$username';")) -> ID;

		// fix for Error “Trying to get property of non-object” - if mysqli_num_rows(...) else
		if(mysqli_num_rows($this->db->execute("SELECT `fk_blokID` FROM `administratie` WHERE `fk_gebruikerID` = '$userID';")) > 0) {
			$myBlock = mysqli_fetch_object($this->db->execute("SELECT `fk_blokID` FROM `administratie` WHERE `fk_gebruikerID` = '$userID';")) -> fk_blokID;
			return $myBlock;
		} else {
			return false;
		}
	}

	public function deleteReservation($username,$BlockID) {
		// DELETE FROM `programma` WHERE `programma`.`BlokID` = 25;
		$userID = mysqli_fetch_object($this->db->execute("SELECT `ID` FROM `gebruikers` WHERE `gebruikersnaam` = '$username';")) -> ID;
		$this->db->execute("DELETE FROM `administratie` WHERE `administratie`.`fk_gebruikerID` = '$userID' && `administratie`.`fk_blokID` = '$BlockID';");

		/* todo: ben niet meer aan toegekomen om programma bij te werken met Plus aantal */
	}

}

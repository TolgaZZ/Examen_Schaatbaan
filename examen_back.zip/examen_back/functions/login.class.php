<?php
class Login 
{
    private $query;

	public function __construct()
	{
		$this->query = new databaseManager();
	}
	
	public function login($username,$password)
	{
		if($this->query->login($username,$password))
		{
			$_SESSION['logged']['username'] = $username;
			$_SESSION['logged']['usertype'] = mysqli_fetch_object($this->query->getUserType($username,$password)) -> type;
			return true;
		}
		else {
			return false;
		}
	}
}
?>


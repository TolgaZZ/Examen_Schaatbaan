<!doctype html>

<?php
include "config.php";
$dbManager = new databaseManager();

if (isset($_POST['login'])) {
  $login = new login();
  if ($login->login($_POST['inputUsername'], $_POST['inputPassword'])) {
  }
}

if (isset($_SESSION['logged'])) {

  if (isset($_GET['guid']) && isset($_GET['annuleer'])) {

    $dbManager->deleteReservation($_SESSION['logged']['username'], $_GET['guid']);

  } else if (isset($_GET['guid'])) {

    $block_result = $dbManager->getBlock($_GET['guid']);
    if (mysqli_num_rows($block_result) == 1) {
      $block_item = mysqli_fetch_array($block_result);
      $dbManager->claimSpot($block_item['BlokID'], $block_item['blok'], $block_item['datum_van'], $block_item['datum_tot'], $block_item['aantal_plekken'], $_SESSION['logged']['username']);
    }
  }
}

?>

<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <title>De Klapschaats</title>

  <!-- Bootstrap core CSS -->
  <link href="/assets/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">

  <!-- Favicons -->
  <!-- Fase 3 SEO optimalisatie -->

  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
  </style>

  <!-- Custom styles for this template -->
  <link href="/assets/thema/jumbotron.css" rel="stylesheet">
</head>

<body>

  <?php include('snippets/navigation.php'); ?>

  <main role="main">

    <div class="jumbotron">
      <div class="container">
        <h1 class="display-3">De Klapschaats gebruikers</h1>

        <?php
        if (isset($_SESSION['logged'])) {
          echo "<p>Overzicht gebruikers</p>";
        } else {
        ?>
          <br />
          <p>U moet eerst inloggen om overzicht gebruikers te zien</p>
          Dummy data: Admin | #1Geheim <br><br>

          <form action="<?php print $_SERVER['PHP_SELF'] ?>" method='post'>
            <div class="form-group">
              <label for="inputUsername">Gebruikersnaam</label>
              <input class="form-control" id="inputUsername" name="inputUsername" value="">
            </div>
            <div class="form-group">
              <label for="inputPassword">Wachtwoord</label>
              <input type="password" class="form-control" id="inputPassword" name="inputPassword" value="">
            </div>
            <button type="submit" name="login" value="true" class="btn btn-primary">login</button>
          </form>
        <?php
        }
        ?>

      </div>
    </div>

    <div class="container">
      <div class="row">
        <div class="col-md-12 mb-3">
          Gebruikers
        </div>
        <div class="col-md-12 mb-3">
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">Gebruiksnaam</th>
                <th scope="col">Lid</th>
                <th scope="col">Link</th>
              </tr>
            </thead>
            <tbody>
              <?php
              foreach ($dbManager->getUserList() as $row) {
                echo "" .
                  "<tr>" .
                  "<td>" . $row["gebruikersnaam"] . "</td>" .
                  "<td>" . $row["lid"] . "</td>" .
                  "<td><a href='/account.php?guid=" . $row["ID"] . "'>edit</td>" .
                "</tr>";
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>


  </main>

  <?php include('snippets/footer.php'); ?>

</body>

</html>
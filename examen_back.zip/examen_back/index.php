<!doctype html>

<?php
include "config.php"; //dankzij dit worden alle php libraries ingeladen en db connectie opgezet.
$dbManager = new databaseManager();

if (isset($_POST['login'])) {
  $login = new login();
  if ($login->login($_POST['inputUsername'], $_POST['inputPassword'])) {
  }
}

if (isset($_SESSION['logged'])) {

  if (isset($_GET['guid']) && isset($_GET['annuleer'])) {

    $dbManager->deleteReservation($_SESSION['logged']['username'], $_GET['guid']);

  } else if (isset($_GET['guid'])) {

    $block_result = $dbManager->getBlock($_GET['guid']);
    if (mysqli_num_rows($block_result) == 1) {
      $block_item = mysqli_fetch_array($block_result);
      $dbManager->claimSpot($block_item['BlokID'], $block_item['blok'], $block_item['datum_van'], $block_item['datum_tot'], $block_item['aantal_plekken'], $_SESSION['logged']['username']);
    }
  }
}

?>

<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <title>De Klapschaats</title>

  <!-- Bootstrap core CSS -->
  <link href="/assets/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">

  <!-- Favicons -->
  <!-- Fase 3 SEO optimalisatie -->

  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
  </style>

  <!-- Custom styles for this template -->
  <link href="/assets/thema/jumbotron.css" rel="stylesheet">
</head>

<body>

  <?php include('snippets/navigation.php'); ?>

  <main role="main">

    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron">
      <div class="container">
        <h1 class="display-3">De Klapschaats!</h1>

        <?php
        // UserType moet groter dan admin zijn, admin type == 1
        if (isset($_SESSION['logged'])) {
          echo "<p>Welkom schaatsliefhebber, reserveer uw plek of bekijk uw reservering!</p>";
        } else {
        ?>
          <br />
          <p>U moet eerst inloggen voordat u een reservering kan doen!</p>
          Dummy data: Hans002 | 123456 <br><br>
          <form action="<?php print $_SERVER['PHP_SELF'] ?>" method='post'>
            <div class="form-group">
              <label for="inputUsername">Gebruikersnaam</label>
              <input class="form-control" id="inputUsername" name="inputUsername" value="">
            </div>
            <div class="form-group">
              <label for="inputPassword">Wachtwoord</label>
              <input type="password" class="form-control" id="inputPassword" name="inputPassword" value="">
            </div>
            <button type="submit" name="login" value="true" class="btn btn-primary">login</button>
          </form>
        <?php
        }
        ?>

      </div>
    </div>

    <?php
    if (isset($_SESSION['logged'])) {
    ?>

      <div class="container">
        <div class="row">
          <div class="col-md-12 mb-3">

            <h2>Mijn reservering:</h2>

            <?php
            if (isset($_SESSION['logged'])) {

              if ($dbManager->getReservation($_SESSION['logged']['username'])) {
                $myReservation = $dbManager->getReservation($_SESSION['logged']['username']);

                $block_result = $dbManager->getBlock($myReservation);
                if (mysqli_num_rows($block_result) == 1) {
                  $block_item = mysqli_fetch_array($block_result);

                  echo "Blok: " . $block_item['blok'] . ", van: " . date("d-M-Y H:i", strtotime($block_item["datum_van"])) . " tot: " . date("H:i", strtotime($block_item['datum_tot']));
                  echo " <a href='" . $_SERVER['PHP_SELF'] . "?guid=" . $block_item["BlokID"] . "&amp;annuleer=true'>annuleer</a>";
                  echo "<br><br>";
                } else {
                  echo "Geselecteerde 'blok' bestaat niet";
                }
              }
            }
            ?>
          </div>
        </div>
      </div>
    <?php
    }
    ?>

    <div class="container">
      <div class="row">
        <div class="col-md-12 mb-3">
          Kies uw plek tijd/datum uit!
        </div>
        <div class="col-md-12 mb-3">
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">Blok</th>
                <th scope="col">Datum</th>
                <th scope="col">Van</th>
                <th scope="col">Tot</th>
                <th scope="col">Beschikbaar plekken</th>
              </tr>
            </thead>
            <tbody>
              <?php
              foreach ($dbManager->getProgramList() as $row) {
                echo "" .
                  "<tr>" .
                  "<td>" . $row["blok"] . "</td>" .
                  "<td><a href='" . $_SERVER['PHP_SELF'] . "?guid=" . $row["BlokID"] . "'>" . date("d-M-Y", strtotime($row["datum_van"])) . "</a></td>" .
                  "<td>" . date("H:i", strtotime($row["datum_van"])) . "</td>" .
                  "<td>" . date("H:i", strtotime($row["datum_tot"])) . "</td>";

                if ($row["aantal_plekken"] > 0) {
                  echo "<td>" . $row["aantal_plekken"] . "</td>";
                } else {
                  echo "<td><span style=\"color:red;font-weight:bold;\">vol</span></td>";
                }
                echo "</tr>";
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>


  </main>

  <?php include('snippets/footer.php'); ?>

</body>

</html>
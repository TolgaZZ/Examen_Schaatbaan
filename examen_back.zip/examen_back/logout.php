<!doctype html>
<?php
include "config.php";
?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <title>De Klapschaats</title>

    <!-- Bootstrap core CSS -->
    <link href="/assets/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">

    <!-- Favicons -->
    <!-- Fase 3 SEO optimalisatie -->

    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }
    </style>


    <!-- Custom styles for this template -->
    <link href="/assets/thema/jumbotron.css" rel="stylesheet">
</head>

<body>

    <?php include('snippets/navigation.php'); ?>

    <main role="main">

        <!-- Main jumbotron for a primary marketing message or call to action -->
        <div class="jumbotron">
            <div class="container">
                <h1 class="display-3">Bedankt voor uw bezoek.</h1>
                <?php
                session_destroy();
                echo 'U bent uitgelogd. <a href="/">Ga terug</a>';
                ?>
            </div>
        </div>

    </main>

    <?php include('snippets/footer.php'); ?>

</body>

</html>
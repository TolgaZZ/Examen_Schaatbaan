<?php
include "../config.php";

$dbManager = new databaseManager();
if (isset($_POST['sbm_accountRegister'])) {
    // roep functie insert_new aan
    if ($_POST['iUsername'] !== '') {
      $dbManager->insertUser($_POST['iUsername'], $_POST['iPassword'], $_POST['iFirstname'], $_POST['iLastname'], $_POST['iEmail'], $_POST['iPhone'], $_POST['iAddress'], $_POST['iZipcode'], $_POST['iCity']);
    }
  
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>


<div class="mx-auto" style="width: 400px;">  
  <form action="<?php print $_SERVER['PHP_SELF'] ?>" method="POST">
  <input type="hidden" class="form-control" id="inputBlockID" name="inputBlockID" value="<?php if (isset($_GET['guid'])) echo $block_item['BlokID'];
                                                                                                      else echo -1; ?>">
      <h1>Gebruiker aanmaken</h1>
    <div class="form-group">
      <label for="username">Gebruikersnaam:</label>
      <input type="text" name="username" id="iUsername" placeholder="Gebruikersnaam" class="form-control">
    </div>
    <div class="form-group">
      <label for="password">Wachtwoord:</label>
      <input type="password" class="form-control" id="iPassword" placeholder="Wachtwoord">
    </div>
    <div class="form-group">
      <label for="firstName">Voornaam:</label>
      <input type="text" class="form-control" id="iFirstname" placeholder="Voornaam">
    </div>
    <div class="form-group">
      <label for="lastName">Achternaam:</label>
      <input type="text" class="form-control" id="iLastname" placeholder="Achternaam">
    </div>  
    <div class="form-group">
      <label for="exampleInputEmail1">Email address</label>
      <input type="email" class="form-control" id="iEmail" aria-describedby="emailHelp" placeholder="Email adress">
    </div>
    <div class="form-group">
      <label for="phone">Telefoon Nummer:</label>
      <input type="number" class="form-control" id="iPhone" placeholder="06123456789">
    </div>
  
    <div class="form-group">
      <label for="address">Adress</label>
      <input type="text" class="form-control" id="iAddress" placeholder="Adress">
    </div>
    <div class="form-group">
      <label for="text">postcode:</label>
      <input type="text" class="form-control" name="iZipcode" placeholder="Postcode">
    </div>
    <div class="form-group">
      <label for="text">stad:</label>
      <input type="text" class="form-control" name="iCity" placeholder="Stad">
    </div>
    <div class="form-group">
      <label for="exampleFormControlSelect1">Example select</label>
      <select class="form-control" id="exampleFormControlSelect1">
          <option value="1">Lid</option>
          <option value="2">Geen lid</option>
      </select>
    </div>
    <button type="submit" name="sbm_accountRegister" value="true" class="btn btn-primary">Submit</button>
  <button type="button" class="btn btn-dark mx-auto"><a href="../index.php">Terug naar dashboard</a></button>
  </form>
</div>

</body>
</html>
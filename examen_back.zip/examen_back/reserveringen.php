<!doctype html>

<?php
include "config.php";
$dbManager = new databaseManager();

if (isset($_POST['login'])) {
  $login = new login();
  if ($login->login($_POST['inputUsername'], $_POST['inputPassword'])) {
  }
}

?>

<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <title>De Klapschaats</title>

  <!-- Bootstrap core CSS -->
  <link href="/assets/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">

  <!-- Favicons -->
  <!-- Fase 3 SEO optimalisatie -->

  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
  </style>

  <!-- Custom styles for this template -->
  <link href="/assets/thema/jumbotron.css" rel="stylesheet">
</head>

<body>

  <?php include('snippets/navigation.php'); ?>

  <main role="main">

    <div class="jumbotron">
      <div class="container">
        <h1 class="display-3">De Klapschaats reserveringen</h1>

        <?php
        if (isset($_SESSION['logged'])) {
          echo "<p>Overzicht reserveringen</p>";
        } else {
        ?>
          <br />
          <p>U moet eerst inloggen om overzicht gebruikers te zien</p>
          Dummy data: Admin | #1Geheim <br><br>

          <form action="<?php print $_SERVER['PHP_SELF'] ?>" method='post'>
            <div class="form-group">
              <label for="inputUsername">Gebruikersnaam</label>
              <input class="form-control" id="inputUsername" name="inputUsername" value="">
            </div>
            <div class="form-group">
              <label for="inputPassword">Wachtwoord</label>
              <input type="password" class="form-control" id="inputPassword" name="inputPassword" value="">
            </div>
            <button type="submit" name="login" value="true" class="btn btn-primary">login</button>
          </form>
        <?php
        }
        ?>

      </div>
    </div>

    <div class="container">
      <div class="row">
        <div class="col-md-12 mb-3">
            Reserveringen, kies een blok om te bekijken wie allemaal ingeschreven hebben:

            <form action="<?php print $_SERVER['PHP_SELF'] ?>" method='post'>
            <div class="form-group">
              <label for="admin">Kies blok</label>

              <select class="form-control" id="dagdeel" name="dagdeel">
              <?php foreach ($dbManager->getProgramList() as $row) {
                echo '<option value="' . $row['BlokID'] . '">';
                echo "Blok: " . $row['blok'] . ", van: " . date("d-M-Y H:i", strtotime($row["datum_van"])) . " tot: " . date("H:i", strtotime($row['datum_tot']));
                echo '</option>';
            } ?>
              </select>
            </div>
            <button type="submit" name="submit" value="true" class="btn btn-primary">submit</button>
          </form>

        </div>
      </div>
    </div>



    <div class="container">
      <div class="row">
        <div class="col-md-12 mb-3">

        <?php
                  if (isset($_SESSION['logged'])) {

                    if (isset($_POST['dagdeel'])) {
                      echo "<br><span style='color:red;'>Todo get overzicht van reserveringen BlokID: ".  $_POST['dagdeel']."</span><br><br> ";
                    }
                    
                    }
              ?>

        </div>
      </div>
    </div>


  </main>

  <?php include('snippets/footer.php'); ?>

</body>

</html>
<footer class="container">
    <p>2021 &copy; De Klapschaats. Alle rechten voorbehouden.</p>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
<script>
    window.jQuery || document.write('<script src="/assets/js/jquery.slim.min.js"><\/script>')
</script>
<script src="/assets/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
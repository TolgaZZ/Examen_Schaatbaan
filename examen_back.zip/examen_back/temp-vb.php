<!-- Dit is mijn mac clipboard vananf nu  -->
    <div class="container">
      <!-- Example row of columns -->
      <div class="row">
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Will you do the same for me? It's time to face the music I'm no longer your muse. Heard it's beautiful, be the judge and my girls gonna take a vote. I can feel a phoenix inside of me. Heaven is jealous of our love, angels are crying from up above. Yeah, you take me to utopia.</p>
          <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
        </div>
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Standing on the frontline when the bombs start to fall. Heaven is jealous of our love, angels are crying from up above. Can't replace you with a million rings. Boy, when you're with me I'll give you a taste. There’s no going back. Before you met me I was alright but things were kinda heavy. Heavy is the head that wears the crown.</p>
          <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
        </div>
        <div class="col-md-4">
          <h2>Heading</h2>
          <p>Playing ping pong all night long, everything's all neon and hazy. Yeah, she's so in demand. She's sweet as pie but if you break her heart. But down to earth. It's time to face the music I'm no longer your muse. I guess that I forgot I had a choice.</p>
          <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
        </div>
      </div>

      <hr>

    </div> <!-- /container -->


    <?php


if(isset($_POST['login']) && isset($_POST['username']))
{
	$login = new login();
	if($login->login($_POST['username'],$_POST['password']))
	{
        header('Location: pages/dashboard.php');
        echo "test je username is: " . $_SESSION['logged']['username'] . "<br />";
        echo "blabla " . $_SESSION['logged']['userLevel'] . "<br />";
		// if ($_SESSION['logged']['userLevel'] > 1) {
        //     echo "Ik ben admin mijn level is 999 - " . $_POST['username'];
		// } else {
        //     echo "Ik ben geen admin mijn level is 0 - " . $_POST['username'];            
		// }
	}
}

$datum =  date("d-m-Y H:i:s", time());

    // if ($_SESSION['logged']['userLevel'] > 1) {
    //     echo "Ik ben admin mijn level is 999 - " . $_POST['username'];
    // } else {
    //     echo "Ik ben geen admin mijn level is 0 - " . $_POST['username'];            
    // }
    

    ?>


<?php
        // UserType moet groter dan admin zijn, admin type == 1
        if (isset($_SESSION['logged']) && $_SESSION['logged']['usertype'] > 1) {
          echo "<p>Welkom schaatsliefhebber, reserveer uw plek of bekijk uw reservering!</p>";
        } else {
        }
        ?>

        Probleem met SQL : ALTER TABLE `gebruikers` auto_increment = 12345
        